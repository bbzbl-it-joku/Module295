package ch.ilv.m295.demoapp.department;

import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.NonNull;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Validated
public class DepartmentController {

    private final DepartmentService departmentService;

    DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @GetMapping("api/department")
    public ResponseEntity<List<Department>> all() {
        List<Department> result = departmentService.getDepartments();
        return new ResponseEntity<>(result, HttpStatus.OK);
    }

    @GetMapping("api/department/{id}")
    public ResponseEntity<Department> one(@PathVariable @NonNull Long id) {
        Department department = departmentService.getDepartment(id);
        return new ResponseEntity<>(department, HttpStatus.OK);
    }

    @PostMapping("api/department")
    public ResponseEntity<Department> newDepartment(@Valid @RequestBody @NonNull Department department) {
        Department savedDepartment = departmentService.insertDepartment(department);
        return new ResponseEntity<>(savedDepartment, HttpStatus.OK);
    }

    @PutMapping("api/department/{id}")
    public ResponseEntity<Department> updateDepartment(@Valid @RequestBody @NonNull Department department, @PathVariable @NonNull Long id) {
        Department savedDepartment = departmentService.updateDepartment(department, id);
        return new ResponseEntity<>(savedDepartment, HttpStatus.OK);
    }

    @DeleteMapping("api/department/{id}")
    public void deleteDepartment(@PathVariable @NonNull Long id) {
        departmentService.deleteDepartment(id);
    }
}
