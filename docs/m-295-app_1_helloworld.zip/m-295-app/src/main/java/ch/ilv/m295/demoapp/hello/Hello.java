package ch.ilv.m295.demoapp.hello;

public class Hello {
    private String hello;
    public String getHello() {
        return hello;
    }

    public void setHello(String hello) {
        this.hello = hello;
    }

    public Hello (String name) {
        this.hello = String.format("Hello %s!", name);
    }
}
