package ch.ilv.m295.demoapp.department;

import lombok.Data;

@Data
public class Department {
    private Long id;
    private String name;

    public Department(Long id, String name) {
        this.id = id;
        this.name = name;
    }
}
