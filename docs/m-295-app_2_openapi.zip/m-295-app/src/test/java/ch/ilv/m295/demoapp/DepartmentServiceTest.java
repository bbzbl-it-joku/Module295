package ch.ilv.m295.demoapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import java.util.List;

import ch.ilv.m295.demoapp.department.Department;
import ch.ilv.m295.demoapp.department.DepartmentRepository;

class DepartmentServiceTest {

    private DepartmentRepository departmentRepository = new DepartmentRepository();
        
    @Test
    void findDepartment() {
        Department department = departmentRepository.getDepartment(2L);
        assertEquals(2L, department.getId());
    }

    @Test
    void findDepartments () {
        List<Department> departments = departmentRepository.getDepartments();
        assertEquals(2, departments.size());
    }
}
