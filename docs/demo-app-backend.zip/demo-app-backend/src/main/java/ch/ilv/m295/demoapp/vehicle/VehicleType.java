package ch.ilv.m295.demoapp.vehicle;

public enum VehicleType {
    CAR,
    BICYCLE
}
