package ch.ilv.m295.demoapp.warehouse;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Entity
public class Warehouse {
    
    @Id
    @GeneratedValue
    Long id;
    
    @Column(nullable = false)
    @Size(max = 255)
    @NotEmpty
    private String name;

    public Warehouse () {}

    public Warehouse (String name) {
        this.name = name;
    }

}