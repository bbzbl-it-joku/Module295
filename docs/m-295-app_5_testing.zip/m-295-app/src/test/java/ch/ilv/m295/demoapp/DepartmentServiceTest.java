package ch.ilv.m295.demoapp;

import org.junit.jupiter.api.*;

import ch.ilv.m295.demoapp.department.Department;
import ch.ilv.m295.demoapp.department.DepartmentRepository;
import ch.ilv.m295.demoapp.department.DepartmentService;

import static org.mockito.Mockito.*;

public class DepartmentServiceTest {

    private DepartmentService departmentService;
    private final DepartmentRepository departmentRepositoryMock = mock(DepartmentRepository.class);

    private final Department departmentMock = mock(Department.class);

    @BeforeEach
    void setUp() {
        departmentService = new DepartmentService(departmentRepositoryMock);
    }

    @Test
    void createDepartment() {
        when(departmentRepositoryMock.save(departmentMock)).thenReturn(departmentMock);
        departmentService.insertDepartment(departmentMock);
        verify(departmentRepositoryMock, times(1)).save(any());
    }

    @Test
    void deleteDepartment() {
        departmentService.deleteDepartment(any());
        verify(departmentRepositoryMock, times(1)).deleteById(any());
    }

}
