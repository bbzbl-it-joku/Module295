package ch.ilv.m295.demoapp;

import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.json.JacksonJsonParser;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.http.MediaType;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


import ch.ilv.m295.demoapp.department.Department;
import ch.ilv.m295.demoapp.department.DepartmentRepository;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@AutoConfigureMockMvc
@AutoConfigureTestDatabase (replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback()
public class DepartmentControllerTest {
    
    @Autowired
    private MockMvc api;

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private ObjectMapper mapper;

    @Test
    public void testGetDepartments() throws Exception {
        String accessToken = obtainAccessToken("user","user");

        this.departmentRepository.save(new Department("Abteilung A"));

        api.perform(
            get("/api/department")
                .header("Authorization", "Bearer " + accessToken)
        )
        .andDo(print()).andExpect(status().isOk())
        .andExpect(content().string(containsString("Abteilung A")));

    }

    @Test
    public void testGetDepartment() throws Exception {
        String accessToken = obtainAccessToken("user","user");

        Department newDepartment = new Department("Abteilung XY");
        this.departmentRepository.save(newDepartment);

        String url = String.format("/api/department/%s", newDepartment.getId());

        api.perform(
            get(url)
                .header("Authorization", "Bearer " + accessToken)
        )
        .andDo(print()).andExpect(status().isOk())
        .andExpect(content().string(containsString("Abteilung XY")));

    }

    @Test
    public void testPostDepartment() throws Exception {
        String accessToken = obtainAccessToken("admin","admin");
        Department newDepartment = new Department("Neue Abteilung");

        api.perform(
            post("/api/department")
                .header("Authorization", "Bearer " + accessToken)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(this.mapper.writeValueAsString(newDepartment))
        )
        .andDo(print()).andExpect(status().isOk())
        .andExpect(content().string(containsString("Neue Abteilung")));
    }

    @Test
    public void testPutDepartment() throws Exception {
        String accessToken = obtainAccessToken("admin","admin");

        Department newDepartment = new Department("Abteilung XY");
        this.departmentRepository.save(newDepartment);

        String url = String.format("/api/department/%s", newDepartment.getId());

        newDepartment.setName("Abteilung Neuer Name");

        api.perform(
            put(url)
                .header("Authorization", "Bearer " + accessToken)
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON)
                .content(this.mapper.writeValueAsString(newDepartment))
        )
        .andDo(print()).andExpect(status().isOk())
        .andExpect(content().string(containsString("Abteilung Neuer Name")));
    }

    @Test
    public void testDeleteDepartment() throws Exception {
        String accessToken = obtainAccessToken("admin","admin");

        Department newDepartment = new Department("Keine Abteilung");
        this.departmentRepository.save(newDepartment);

        String url = String.format("/api/department/%s", newDepartment.getId());
    
        api.perform(
            delete(url)
                .header("Authorization", "Bearer " + accessToken)
        )
        .andDo(print()).andExpect(status().isOk());
    }


    private String obtainAccessToken(String username, String password) {

        RestTemplate rest = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        String body = "client_id=demoapp&" +
                "grant_type=password&" +
                "scope=openid profile roles offline_access&" +
                String.format("username=%s&", username) +
                String.format("password=%s", password);

        HttpEntity<String> entity = new HttpEntity<>(body, headers);

        ResponseEntity<String> resp = rest.postForEntity(
            "http://localhost:8080/realms/ILV/protocol/openid-connect/token", 
            entity, 
            String.class
        );

        JacksonJsonParser jsonParser = new JacksonJsonParser();
        return jsonParser.parseMap(resp.getBody()).get("access_token").toString();
    }
}
